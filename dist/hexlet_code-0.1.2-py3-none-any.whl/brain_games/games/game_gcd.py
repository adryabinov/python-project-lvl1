#!/usr/bin/env python
import random


def make_game(seed=random.random()):
    """seed = random return: TODO: game rule, qestion string, answer,"""
    game_rules = "even rule: TODO REWRITE"
    question_number = 0
    question_answer = 0
    return str(question_number), str(question_answer), str(game_rules)